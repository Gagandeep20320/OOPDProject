from setuptools import setup
setup(name="packageoopd",
version = "1",
description="This is our project of endsem",
author="Group7", 
packages = ['packageoopd'],
install_requires = [])