from setuptools import setup
setup(name="packageoopd",
version = "2",
description="This is an assembler",
author="Group7", 
packages = ['packageoopd'],
install_requires = ["multipledispatch", "matplotlib", "abcplus"])