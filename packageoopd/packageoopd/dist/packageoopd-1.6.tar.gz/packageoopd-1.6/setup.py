from setuptools import setup
setup(name="packageoopd",
version = "1.6",
description="This is an assembler",
author="Group7", 
packages = ['packageoopd'],
install_requires = [])